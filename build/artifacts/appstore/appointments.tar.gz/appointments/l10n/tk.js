OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ýatyrmak",
    "Password" : "Açarsöz",
    "Delete" : "Pozmak",
    "Settings" : "Sazlamalar",
    "Close" : "Ýap",
    "Remove" : "Aýyrmak",
    "Save" : "Saklamak",
    "OK" : "Bolýar",
    "30 minutes" : "30 minut",
    "1 hour" : "1 sagat",
    "4 hours" : "4 sagat",
    "Loading…" : "Ýüklenýär…",
    "Edit" : "Redaktirläň",
    "Error" : "ýalňyşlyk",
    "Deleted" : "Öçürildi",
    "Location:" : "Locationerleşýän ýeri:",
    "Back" : "Yzyna",
    "Name" : "Ady"
},
"nplurals=2; plural=(n != 1);");
